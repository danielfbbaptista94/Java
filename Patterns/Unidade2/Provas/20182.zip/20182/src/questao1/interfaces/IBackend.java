package questao1.interfaces;

public interface IBackend 
{
    public void drawSprite();
    public void detectCollision();
}
